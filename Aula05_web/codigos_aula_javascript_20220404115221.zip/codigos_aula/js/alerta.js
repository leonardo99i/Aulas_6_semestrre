var alertar = function () {
    alert("Você clicou no botão");
}

var avisarMouse = function() {
    alert("Você tirou o mouse de cima do botão");
}