itens_menu = ["Home", "Contato", "Sobre"];
document.write("<ul>");
for (item of itens_menu) {
    document.write("<li>" + item + "</li>");
}
document.write("</ul>");