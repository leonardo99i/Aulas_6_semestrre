function mudarbotao() {
    var elementoTexto = document.getElementById("nome");
    elementoTexto.value = "Apertou o botão";
    elementoTexto.style.backgroundColor = "red";
}

function voltaraonormal() {
    var elementoTexto = document.getElementById("nome");
    elementoTexto.value = "";
    elementoTexto.style.backgroundColor = "white";
}