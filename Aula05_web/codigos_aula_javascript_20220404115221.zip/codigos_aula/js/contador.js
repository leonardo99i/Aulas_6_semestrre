document.write("Vamos contar: ");
for(i=1; i<=10; i++) {
    document.write("Contando " + i + "<br>");
}